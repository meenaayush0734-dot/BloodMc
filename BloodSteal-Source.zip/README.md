# BloodSteal v2 (Paper 1.21.11, Java 21)

## .jar kaise banaye
**Option A - Phone se (GitHub Actions):**
1. Is poore folder ko ek GitHub repo me upload karo.
2. Repo > Actions > "Build BloodSteal" > Run workflow.
3. Run khatam hone par "BloodSteal-jar" artifact download karo -> andar `BloodSteal.jar`.

**Option B - PC se:** JDK 21 + Maven install karo, folder me `mvn package` chalao -> `target/BloodSteal.jar`.

## Install
- `BloodSteal.jar` ko server ke `plugins/` folder me daalo, server restart karo.
- Custom icons ke liye `BloodSteal-ResourcePack.zip` players ko do (ya host karke `config.yml > resource-pack.url` me link daalo).
  Pack ke bina gems normal vanilla item jaise dikhte hain (kuch toot-phoot nahi hota).

## Commands
- `/bwithdraw <amount>` - blood ko Blood Vial item me nikalo (kam se kam 10% bacha rehta hai).
- `/bloodsteal give <player> <blood|crimson|shadow|inferno|averon|vial [amount]>`
- `/bloodsteal check|set|add|reset <player> [n]`, `/bloodsteal reload`

## Gems (right-click = ability, sab config.yml me)
| Gem | Max blood | Ability |
|---|---|---|
| Blood | 150% | Blood Burst |
| Crimson | 250% | Crimson Rage (Strength I, 10s) |
| Shadow | 400% | Shadow Blink (8 block) |
| Inferno | 600% | Infernal Execution |
| Averon | 900% | Blood Dominion (right-click), Averon Rift (sneak + right-click), Supreme Blood (passive) |

Max blood = base-max (200) x gem multiplier / 100. Sabse strong gem hi count hota hai.
