package dev.bloodsteal;

import org.bukkit.Keyed;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;

public final class GemListener implements Listener {

    private final BloodStealPlugin plugin;
    private final ItemManager items;
    private final AbilityManager abilities;

    public GemListener(BloodStealPlugin plugin, ItemManager items, AbilityManager abilities) {
        this.plugin = plugin;
        this.items = items;
        this.abilities = abilities;
    }

    /** Right-click with a gem in the main hand uses its ability. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;

        GemType gem = items.gemOf(e.getItem());
        if (gem == null) return;

        Player p = e.getPlayer();
        if (a == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable() && !p.isSneaking()) {
            return; // let the player open chests, doors, etc.
        }
        e.setUseItemInHand(Event.Result.DENY);
        abilities.use(p, gem);
    }

    /**
     * Crafting validation:
     *  - our gem recipes need exactly the previous-tier custom gem (checked via NBT, not just material)
     *  - the vial recipe and tier-1 gem accept no custom items
     *  - custom gems / vials can never be used as ingredients in any other recipe
     */
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        ItemStack[] matrix = e.getInventory().getMatrix();
        int custom = 0;
        String foundGem = null;
        for (ItemStack s : matrix) {
            if (s == null) continue;
            GemType g = items.gemOf(s);
            if (g != null) {
                custom++;
                foundGem = g.id();
            } else if (items.vialAmount(s) != null) {
                custom++;
                foundGem = "vial";
            }
        }
        if (custom == 0) {
            // A tier 2+ recipe filled with plain vanilla items must not work.
            Recipe r = e.getRecipe();
            if (r instanceof Keyed k) {
                String need = items.requirementOf(k.getKey());
                if (need != null && !need.isEmpty()) {
                    e.getInventory().setResult(null);
                }
            }
            return;
        }

        Recipe r = e.getRecipe();
        String need = null;
        if (r instanceof Keyed k) {
            NamespacedKey key = k.getKey();
            need = items.requirementOf(key);
        }
        if (need == null) {
            e.getInventory().setResult(null); // foreign recipe: custom items not allowed
            return;
        }
        if (need.isEmpty() || custom != 1 || !need.equals(foundGem)) {
            e.getInventory().setResult(null);
        }
    }

    /** Gems/vials survive fire, lava, explosions and cacti when dropped. */
    @EventHandler(ignoreCancelled = true)
    public void onItemDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Item item && items.isCustom(item.getItemStack())) {
            if (e.getCause() != EntityDamageEvent.DamageCause.VOID) {
                e.setCancelled(true);
            }
        }
    }

    /** Averon passive: Supreme Blood. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            abilities.supremeBlood(p, e.getFinalDamage());
        }
    }
}
