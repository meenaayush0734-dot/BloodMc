package dev.bloodsteal;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Creates / identifies gems and blood vials and owns all custom recipes. */
public final class ItemManager {

    private final BloodStealPlugin plugin;
    private final NamespacedKey gemKey;
    private final NamespacedKey vialKey;
    private final NamespacedKey vialRecipeKey;

    private final List<NamespacedKey> recipeKeys = new ArrayList<>();
    /** recipe key -> required previous gem id ("" = no custom item allowed). */
    private final Map<NamespacedKey, String> requirement = new HashMap<>();

    public ItemManager(BloodStealPlugin plugin) {
        this.plugin = plugin;
        this.gemKey = new NamespacedKey(plugin, "gem_id");
        this.vialKey = new NamespacedKey(plugin, "vial_amount");
        this.vialRecipeKey = new NamespacedKey(plugin, "blood_vial");
    }

    // ------------------------------------------------------------------ items

    public double multiplier(GemType g) {
        double def = switch (g) {
            case BLOOD -> 150;
            case CRIMSON -> 250;
            case SHADOW -> 400;
            case INFERNO -> 600;
            case AVERON -> 900;
        };
        return plugin.getConfig().getDouble("gems." + g.id() + ".blood-multiplier", def);
    }

    public ItemStack createGem(GemType g) {
        FileConfiguration c = plugin.getConfig();
        String base = "gems." + g.id() + ".";
        ItemStack it = new ItemStack(g.material());
        ItemMeta m = it.getItemMeta();

        m.displayName(Msg.item(c.getString(base + "name", g.id() + " gem")));
        List<Component> lore = new ArrayList<>();
        for (String line : c.getStringList(base + "lore")) {
            lore.add(Msg.item(line.replace("{multiplier}", Msg.fmt(multiplier(g)))));
        }
        m.lore(lore);

        m.getPersistentDataContainer().set(gemKey, PersistentDataType.STRING, g.id());
        applyModel(m, g.model());
        m.setEnchantmentGlintOverride(true);
        m.setMaxStackSize(1);

        it.setItemMeta(m);
        return it;
    }

    public ItemStack createVial(double amount) {
        FileConfiguration c = plugin.getConfig();
        String amt = Msg.fmt(amount);
        ItemStack it = new ItemStack(Material.HONEY_BOTTLE);
        ItemMeta m = it.getItemMeta();

        m.displayName(Msg.item(c.getString("vial.name", "<red>Blood Vial").replace("{amount}", amt)));
        List<Component> lore = new ArrayList<>();
        for (String line : c.getStringList("vial.lore")) {
            lore.add(Msg.item(line.replace("{amount}", amt)));
        }
        m.lore(lore);

        m.getPersistentDataContainer().set(vialKey, PersistentDataType.DOUBLE, amount);
        applyModel(m, "blood_vial");
        m.setEnchantmentGlintOverride(true);

        it.setItemMeta(m);
        return it;
    }

    private void applyModel(ItemMeta m, String model) {
        if (!plugin.getConfig().getBoolean("resource-pack.custom-models", true)) return;
        CustomModelDataComponent cmd = m.getCustomModelDataComponent();
        cmd.setStrings(List.of(model));
        m.setCustomModelDataComponent(cmd);
    }

    public GemType gemOf(ItemStack it) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return null;
        String id = it.getItemMeta().getPersistentDataContainer().get(gemKey, PersistentDataType.STRING);
        return GemType.byId(id);
    }

    public Double vialAmount(ItemStack it) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(vialKey, PersistentDataType.DOUBLE);
    }

    public boolean isCustom(ItemStack it) {
        return gemOf(it) != null || vialAmount(it) != null;
    }

    /** Strongest gem the player currently benefits from (null = none). */
    public GemType strongestGem(Player p) {
        PlayerInventory inv = p.getInventory();
        boolean held = "HELD".equalsIgnoreCase(plugin.getConfig().getString("blood.gem-mode", "INVENTORY"));
        GemType best = null;
        double bestMult = -1;
        List<ItemStack> scan = new ArrayList<>();
        if (held) {
            scan.add(inv.getItemInMainHand());
        } else {
            for (ItemStack s : inv.getStorageContents()) scan.add(s);
        }
        scan.add(inv.getItemInOffHand());
        for (ItemStack s : scan) {
            GemType g = gemOf(s);
            if (g == null) continue;
            double mult = multiplier(g);
            if (mult > bestMult) {
                bestMult = mult;
                best = g;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- recipes

    public List<NamespacedKey> recipeKeys() {
        return recipeKeys;
    }

    /** "" = no custom item allowed, otherwise gem id required. null = not our recipe. */
    public String requirementOf(NamespacedKey key) {
        return requirement.get(key);
    }

    public void unregisterRecipes() {
        for (NamespacedKey k : recipeKeys) {
            Bukkit.removeRecipe(k);
        }
        recipeKeys.clear();
        requirement.clear();
    }

    public void registerRecipes() {
        unregisterRecipes();
        FileConfiguration c = plugin.getConfig();

        for (GemType g : GemType.values()) {
            if (!c.getBoolean("gems." + g.id() + ".recipe.enabled", true)) continue;
            NamespacedKey key = new NamespacedKey(plugin, "gem_" + g.id());
            ShapedRecipe r = new ShapedRecipe(key, createGem(g));

            switch (g) {
                case BLOOD -> {
                    r.shape("RDR", "DTD", "RDR");
                    r.setIngredient('R', Material.REDSTONE_BLOCK);
                    r.setIngredient('D', Material.DIAMOND);
                    r.setIngredient('T', Material.GHAST_TEAR);
                }
                case CRIMSON -> {
                    r.shape("NNN", "CXC", "NNN");
                    r.setIngredient('N', Material.NETHERITE_SCRAP);
                    r.setIngredient('C', Material.CRYING_OBSIDIAN);
                }
                case SHADOW -> {
                    r.shape("EEE", "AXA", "OOO");
                    r.setIngredient('E', Material.ENDER_EYE);
                    r.setIngredient('A', Material.AMETHYST_BLOCK);
                    r.setIngredient('O', Material.OBSIDIAN);
                }
                case INFERNO -> {
                    r.shape("BMB", "NXN", "BMB");
                    r.setIngredient('B', Material.BLAZE_ROD);
                    r.setIngredient('M', Material.MAGMA_BLOCK);
                    r.setIngredient('N', Material.NETHERITE_INGOT);
                }
                case AVERON -> {
                    r.shape("NSN", "EXE", "NTN");
                    r.setIngredient('N', Material.NETHERITE_INGOT);
                    r.setIngredient('S', Material.NETHER_STAR);
                    r.setIngredient('E', Material.ENCHANTED_GOLDEN_APPLE);
                    r.setIngredient('T', Material.TOTEM_OF_UNDYING);
                }
            }

            GemType prev = g.previous();
            if (prev != null) {
                // Slot only matches the base material; PrepareItemCraftEvent validates the real custom gem.
                r.setIngredient('X', new RecipeChoice.MaterialChoice(prev.material()));
            }

            if (Bukkit.addRecipe(r)) {
                recipeKeys.add(key);
                requirement.put(key, prev == null ? "" : prev.id());
            } else {
                plugin.getLogger().warning("Could not register recipe " + key);
            }
        }

        if (c.getBoolean("vial.recipe.enabled", true)) {
            ShapedRecipe vr = new ShapedRecipe(vialRecipeKey, createVial(c.getDouble("vial.recipe.amount", 5)));
            vr.shape("RRR", "GBG", "RRR");
            vr.setIngredient('R', Material.REDSTONE_BLOCK);
            vr.setIngredient('G', Material.GOLD_INGOT);
            vr.setIngredient('B', Material.GLASS_BOTTLE);
            if (Bukkit.addRecipe(vr)) {
                recipeKeys.add(vialRecipeKey);
                requirement.put(vialRecipeKey, "");
            }
        }
    }
}
