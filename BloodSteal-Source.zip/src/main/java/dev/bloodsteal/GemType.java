package dev.bloodsteal;

import org.bukkit.Material;

public enum GemType {
    BLOOD("blood", Material.PRISMARINE_CRYSTALS, "blood_gem", 1),
    CRIMSON("crimson", Material.PRISMARINE_SHARD, "crimson_gem", 2),
    SHADOW("shadow", Material.AMETHYST_SHARD, "shadow_gem", 3),
    INFERNO("inferno", Material.NETHER_BRICK, "inferno_gem", 4),
    AVERON("averon", Material.ECHO_SHARD, "averon_gem", 5);

    private final String id;
    private final Material material;
    private final String model;
    private final int tier;

    GemType(String id, Material material, String model, int tier) {
        this.id = id;
        this.material = material;
        this.model = model;
        this.tier = tier;
    }

    public String id() { return id; }
    public Material material() { return material; }
    /** Value of the custom_model_data string used by the resource pack. */
    public String model() { return model; }
    public int tier() { return tier; }

    public GemType previous() {
        return tier == 1 ? null : values()[ordinal() - 1];
    }

    public static GemType byId(String id) {
        if (id == null) return null;
        for (GemType g : values()) {
            if (g.id.equalsIgnoreCase(id)) return g;
        }
        return null;
    }
}
