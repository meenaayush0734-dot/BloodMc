package dev.bloodsteal;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Blood storage (player PDC), max-blood calculation, action bar and banning. */
public final class BloodManager {

    private final BloodStealPlugin plugin;
    private final ItemManager items;
    private final NamespacedKey bloodKey;

    private final Map<UUID, Double> lastMax = new HashMap<>();
    private final Map<UUID, Long> dominionUntil = new HashMap<>();
    private BukkitTask task;

    public BloodManager(BloodStealPlugin plugin, ItemManager items) {
        this.plugin = plugin;
        this.items = items;
        this.bloodKey = new NamespacedKey(plugin, "blood");
    }

    // ------------------------------------------------------------- lifecycle

    public void start() {
        long interval = Math.max(2L, plugin.getConfig().getLong("blood.actionbar-interval-ticks", 10L));
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.isDead()) continue;
                recompute(p);
                sendBar(p);
            }
        }, 20L, interval);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    public void initPlayer(Player p) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        Double v = pdc.get(bloodKey, PersistentDataType.DOUBLE);
        if (v == null) {
            pdc.set(bloodKey, PersistentDataType.DOUBLE, plugin.getConfig().getDouble("blood.start", 200));
        } else if (v <= 0.0001) {
            // Player was banned for 0 blood and got unbanned.
            pdc.set(bloodKey, PersistentDataType.DOUBLE, plugin.getConfig().getDouble("blood.unban-blood", 100));
        }
        lastMax.remove(p.getUniqueId());
        recompute(p);
    }

    public void forget(Player p) {
        lastMax.remove(p.getUniqueId());
        dominionUntil.remove(p.getUniqueId());
    }

    // ----------------------------------------------------------------- blood

    public double getBlood(Player p) {
        Double v = p.getPersistentDataContainer().get(bloodKey, PersistentDataType.DOUBLE);
        return v == null ? plugin.getConfig().getDouble("blood.start", 200) : v;
    }

    private void setRaw(Player p, double v) {
        p.getPersistentDataContainer().set(bloodKey, PersistentDataType.DOUBLE, Math.max(0, v));
    }

    public double getMax(Player p) {
        double base = plugin.getConfig().getDouble("blood.base-max", 200);
        GemType g = items.strongestGem(p);
        double mult = g == null ? 100 : items.multiplier(g);
        double max = base * mult / 100.0;
        if (isDominionActive(p)) {
            max += plugin.getConfig().getDouble("gems.averon.abilities.blood-dominion.blood-bonus", 100);
        }
        return max;
    }

    /** Keeps current blood consistent with the (possibly changed) max: gaining max adds blood, losing max clamps. */
    public void recompute(Player p) {
        double max = getMax(p);
        double cur = getBlood(p);
        Double last = lastMax.get(p.getUniqueId());
        if (last != null && max > last) {
            cur += max - last;
        }
        cur = Math.min(cur, max);
        setRaw(p, cur);
        lastMax.put(p.getUniqueId(), max);
    }

    public void setBlood(Player p, double v) {
        setRaw(p, Math.min(v, getMax(p)));
    }

    /** @return amount actually added. */
    public double addBlood(Player p, double amount) {
        double cur = getBlood(p);
        double add = Math.max(0, Math.min(amount, getMax(p) - cur));
        setRaw(p, cur + add);
        return add;
    }

    /** @return amount actually removed. */
    public double removeBlood(Player p, double amount) {
        double cur = getBlood(p);
        double rem = Math.max(0, Math.min(amount, cur));
        setRaw(p, cur - rem);
        return rem;
    }

    public void giveVial(Player p, double amount) {
        ItemStack vial = items.createVial(amount);
        Map<Integer, ItemStack> left = p.getInventory().addItem(vial);
        for (ItemStack s : left.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), s);
        }
    }

    // -------------------------------------------------------------- dominion

    public void activateDominion(Player p, double seconds) {
        dominionUntil.put(p.getUniqueId(), System.currentTimeMillis() + (long) (seconds * 1000));
        recompute(p);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) recompute(p);
        }, (long) (seconds * 20) + 2L);
    }

    public boolean isDominionActive(Player p) {
        Long until = dominionUntil.get(p.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    // ------------------------------------------------------------------- ban

    public void banForZeroBlood(Player p) {
        String cmd = plugin.getConfig().getString("blood.ban-command", "ban {player} Your blood reached 0%");
        String name = p.getName();
        Bukkit.getScheduler().runTask(plugin, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("{player}", name)));
        Bukkit.broadcast(plugin.msg("banned-broadcast", "player", name));
    }

    // ------------------------------------------------------------- action bar

    public void sendBar(Player p) {
        double cur = getBlood(p);
        double max = Math.max(1, getMax(p));
        int len = Math.max(5, plugin.getConfig().getInt("blood.bar-length", 20));
        int filled = (int) Math.round(cur / max * len);
        filled = Math.max(0, Math.min(len, filled));
        boolean dom = isDominionActive(p);
        String fill = dom ? "<gold>" : "<red>";
        String bar = fill + "\u2588".repeat(filled) + "<dark_gray>" + "\u2591".repeat(len - filled);
        String s = "<dark_red><bold>BLOOD</bold> <dark_gray>[" + bar + "<dark_gray>] <white>"
                + Msg.fmt(cur) + "<gray>% <dark_gray>/ <gray>" + Msg.fmt(max) + "%"
                + (dom ? " <gold>\u2726" : "");
        p.sendActionBar(Msg.parse(s));
    }
}
