package dev.bloodsteal;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class BloodListener implements Listener {

    private final BloodStealPlugin plugin;
    private final BloodManager blood;
    private final ItemManager items;

    public BloodListener(BloodStealPlugin plugin, BloodManager blood, ItemManager items) {
        this.plugin = plugin;
        this.blood = blood;
        this.items = items;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        blood.initPlayer(p);

        if (plugin.getConfig().getBoolean("recipes.discover-on-join", true)) {
            p.discoverRecipes(items.recipeKeys());
        }

        String url = plugin.getConfig().getString("resource-pack.url", "");
        if (url != null && !url.isBlank()) {
            String sha = plugin.getConfig().getString("resource-pack.sha1", "");
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline()) return;
                if (sha == null || sha.isBlank()) {
                    p.setResourcePack(url);
                } else {
                    p.setResourcePack(url, sha);
                }
            }, 40L);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        blood.forget(e.getPlayer());
    }

    /** Only PvP deaths move blood. Natural / mob deaths never touch it. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;

        double loss = blood.removeBlood(victim, plugin.getConfig().getDouble("blood.death-loss", 10));
        if (loss <= 0) return;

        double gain = loss * plugin.getConfig().getDouble("blood.kill-reward-multiplier", 1.0);
        double added = blood.addBlood(killer, gain);
        double overflow = gain - added;
        if (overflow > 0.001 && plugin.getConfig().getBoolean("blood.drop-overflow", true)) {
            blood.giveVial(killer, overflow);
        }

        victim.sendMessage(plugin.msg("lost-blood", "amount", Msg.fmt(loss), "killer", killer.getName(),
                "blood", Msg.fmt(blood.getBlood(victim))));
        killer.sendMessage(plugin.msg("gained-blood", "amount", Msg.fmt(gain), "victim", victim.getName(),
                "blood", Msg.fmt(blood.getBlood(killer))));

        if (blood.getBlood(victim) <= 0.0001) {
            blood.banForZeroBlood(victim);
        }
    }

    /** Drinking a Blood Vial gives the blood back. */
    @EventHandler(ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent e) {
        Double amt = items.vialAmount(e.getItem());
        if (amt == null) return;
        e.setCancelled(true);

        Player p = e.getPlayer();
        double room = blood.getMax(p) - blood.getBlood(p);
        if (room <= 0.0001) {
            p.sendMessage(plugin.msg("blood-full"));
            return;
        }
        double absorb = Math.min(room, amt);

        EquipmentSlot hand = e.getHand();
        ItemStack inHand = p.getInventory().getItem(hand);
        if (inHand != null && items.vialAmount(inHand) != null) {
            ItemStack rest = inHand.clone();
            rest.setAmount(inHand.getAmount() - 1);
            p.getInventory().setItem(hand, rest.getAmount() <= 0 ? null : rest);
        }

        blood.addBlood(p, absorb);
        double remain = amt - absorb;
        if (remain > 0.001) {
            blood.giveVial(p, remain);
        }
        p.sendMessage(plugin.msg("absorbed", "amount", Msg.fmt(absorb), "blood", Msg.fmt(blood.getBlood(p))));
        p.getWorld().playSound(p.getLocation(), "entity.generic.drink", org.bukkit.SoundCategory.PLAYERS, 1f, 0.8f);
    }
}
