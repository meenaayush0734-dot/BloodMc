package dev.bloodsteal;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class AdminCommand implements TabExecutor {

    private final BloodStealPlugin plugin;
    private final BloodManager blood;
    private final ItemManager items;

    public AdminCommand(BloodStealPlugin plugin, BloodManager blood, ItemManager items) {
        this.plugin = plugin;
        this.blood = blood;
        this.items = items;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage(plugin.msg("admin-usage"));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                plugin.reloadAll();
                s.sendMessage(plugin.msg("reloaded"));
            }
            case "give" -> {
                if (a.length < 3) {
                    s.sendMessage(plugin.msg("admin-usage"));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage(plugin.msg("player-not-found"));
                    return true;
                }
                ItemStack give;
                if (a[2].equalsIgnoreCase("vial")) {
                    double amt = 10;
                    if (a.length >= 4) {
                        try {
                            amt = Double.parseDouble(a[3]);
                        } catch (NumberFormatException ex) {
                            s.sendMessage(plugin.msg("invalid-amount"));
                            return true;
                        }
                    }
                    if (amt <= 0) {
                        s.sendMessage(plugin.msg("invalid-amount"));
                        return true;
                    }
                    give = items.createVial(amt);
                } else {
                    GemType g = GemType.byId(a[2]);
                    if (g == null) {
                        s.sendMessage(plugin.msg("unknown-gem"));
                        return true;
                    }
                    give = items.createGem(g);
                }
                for (ItemStack left : t.getInventory().addItem(give).values()) {
                    t.getWorld().dropItemNaturally(t.getLocation(), left);
                }
                s.sendMessage(plugin.msg("given", "player", t.getName()));
            }
            case "check" -> {
                Player t = a.length >= 2 ? Bukkit.getPlayerExact(a[1]) : (s instanceof Player p ? p : null);
                if (t == null) {
                    s.sendMessage(plugin.msg("player-not-found"));
                    return true;
                }
                s.sendMessage(plugin.msg("check", "player", t.getName(),
                        "blood", Msg.fmt(blood.getBlood(t)), "max", Msg.fmt(blood.getMax(t))));
            }
            case "set", "add" -> {
                if (a.length < 3) {
                    s.sendMessage(plugin.msg("admin-usage"));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage(plugin.msg("player-not-found"));
                    return true;
                }
                double v;
                try {
                    v = Double.parseDouble(a[2]);
                } catch (NumberFormatException ex) {
                    s.sendMessage(plugin.msg("invalid-amount"));
                    return true;
                }
                if (a[0].equalsIgnoreCase("set")) blood.setBlood(t, v);
                else if (v >= 0) blood.addBlood(t, v);
                else blood.removeBlood(t, -v);
                s.sendMessage(plugin.msg("check", "player", t.getName(),
                        "blood", Msg.fmt(blood.getBlood(t)), "max", Msg.fmt(blood.getMax(t))));
            }
            case "reset" -> {
                if (a.length < 2) {
                    s.sendMessage(plugin.msg("admin-usage"));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage(plugin.msg("player-not-found"));
                    return true;
                }
                blood.setBlood(t, plugin.getConfig().getDouble("blood.start", 200));
                s.sendMessage(plugin.msg("check", "player", t.getName(),
                        "blood", Msg.fmt(blood.getBlood(t)), "max", Msg.fmt(blood.getMax(t))));
            }
            default -> s.sendMessage(plugin.msg("admin-usage"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : List.of("reload", "give", "check", "set", "add", "reset")) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            }
        } else if (a.length == 2 && !a[0].equalsIgnoreCase("reload")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        } else if (a.length == 3 && a[0].equalsIgnoreCase("give")) {
            for (String x : List.of("blood", "crimson", "shadow", "inferno", "averon", "vial")) {
                if (x.startsWith(a[2].toLowerCase(Locale.ROOT))) out.add(x);
            }
        }
        return out;
    }
}
