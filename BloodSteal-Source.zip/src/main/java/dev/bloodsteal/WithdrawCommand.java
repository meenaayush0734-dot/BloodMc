package dev.bloodsteal;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

public final class WithdrawCommand implements TabExecutor {

    private final BloodStealPlugin plugin;
    private final BloodManager blood;

    public WithdrawCommand(BloodStealPlugin plugin, BloodManager blood) {
        this.plugin = plugin;
        this.blood = blood;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (args.length != 1) {
            p.sendMessage(plugin.msg("withdraw-usage"));
            return true;
        }

        double amount;
        try {
            amount = Double.parseDouble(args[0]);
        } catch (NumberFormatException ex) {
            p.sendMessage(plugin.msg("invalid-amount"));
            return true;
        }
        if (Double.isNaN(amount) || Double.isInfinite(amount) || amount <= 0) {
            p.sendMessage(plugin.msg("invalid-amount"));
            return true;
        }
        amount = Math.round(amount * 100.0) / 100.0;
        if (amount <= 0) {
            p.sendMessage(plugin.msg("invalid-amount"));
            return true;
        }

        double cur = blood.getBlood(p);
        double minRemain = plugin.getConfig().getDouble("withdraw.min-remaining", 10);
        double maxWithdraw = Math.max(0, cur - minRemain);

        if (maxWithdraw <= 0.0001) {
            p.sendMessage(plugin.msg("withdraw-not-enough", "min", Msg.fmt(minRemain)));
            return true;
        }
        if (amount > maxWithdraw + 0.0001) {
            p.sendMessage(plugin.msg("withdraw-too-much", "max", Msg.fmt(maxWithdraw), "blood", Msg.fmt(cur)));
            return true;
        }

        blood.removeBlood(p, amount);
        blood.giveVial(p, amount);
        p.sendMessage(plugin.msg("withdrawn", "amount", Msg.fmt(amount), "blood", Msg.fmt(blood.getBlood(p))));
        p.getWorld().playSound(p.getLocation(), "block.brewing_stand.brew", org.bukkit.SoundCategory.PLAYERS, 1f, 1f);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1 && sender instanceof Player p) {
            double max = Math.max(0, blood.getBlood(p) - plugin.getConfig().getDouble("withdraw.min-remaining", 10));
            return List.of("10", Msg.fmt(Math.floor(max)));
        }
        return List.of();
    }
}
