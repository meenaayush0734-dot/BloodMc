package dev.bloodsteal;

import net.kyori.adventure.text.Component;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class BloodStealPlugin extends JavaPlugin {

    private ItemManager items;
    private BloodManager blood;
    private AbilityManager abilities;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        items = new ItemManager(this);
        blood = new BloodManager(this, items);
        abilities = new AbilityManager(this, items, blood);

        items.registerRecipes();

        getServer().getPluginManager().registerEvents(new BloodListener(this, blood, items), this);
        getServer().getPluginManager().registerEvents(new GemListener(this, items, abilities), this);

        WithdrawCommand withdraw = new WithdrawCommand(this, blood);
        PluginCommand wc = getCommand("bwithdraw");
        if (wc != null) {
            wc.setExecutor(withdraw);
            wc.setTabCompleter(withdraw);
        }

        AdminCommand admin = new AdminCommand(this, blood, items);
        PluginCommand ac = getCommand("bloodsteal");
        if (ac != null) {
            ac.setExecutor(admin);
            ac.setTabCompleter(admin);
        }

        blood.start();
        getLogger().info("BloodSteal enabled.");
    }

    @Override
    public void onDisable() {
        if (blood != null) blood.stop();
        if (items != null) items.unregisterRecipes();
    }

    public void reloadAll() {
        reloadConfig();
        items.registerRecipes();
    }

    /** Message with prefix, from config messages.<path>. Placeholders: {key} -> value. */
    public Component msg(String path, String... kv) {
        return Msg.parse(getConfig().getString("messages.prefix", "") + raw(path, kv));
    }

    /** Message string without prefix. */
    public String raw(String path, String... kv) {
        String s = getConfig().getString("messages." + path, "<red>Missing message: " + path);
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return s;
    }

    public Component rawC(String path, String... kv) {
        return Msg.parse(raw(path, kv));
    }
}
