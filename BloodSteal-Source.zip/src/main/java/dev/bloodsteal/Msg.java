package dev.bloodsteal;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;

import java.util.Locale;

public final class Msg {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private Msg() {}

    public static Component parse(String s) {
        return MM.deserialize(s == null ? "" : s);
    }

    /** For item names / lore: MiniMessage without the default italic. */
    public static Component item(String s) {
        return parse(s).decoration(TextDecoration.ITALIC, false);
    }

    public static String fmt(double d) {
        if (Math.abs(d - Math.rint(d)) < 0.05) {
            return String.valueOf((long) Math.rint(d));
        }
        return String.format(Locale.US, "%.1f", d);
    }
}
