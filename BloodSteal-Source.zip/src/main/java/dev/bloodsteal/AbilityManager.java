package dev.bloodsteal;

import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/** All gem abilities, cooldowns, effects and team / PvP protection. */
public final class AbilityManager {

    private final BloodStealPlugin plugin;
    private final ItemManager items;
    private final BloodManager blood;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public AbilityManager(BloodStealPlugin plugin, ItemManager items, BloodManager blood) {
        this.plugin = plugin;
        this.items = items;
        this.blood = blood;
    }

    // ------------------------------------------------------------- dispatch

    public void use(Player p, GemType gem) {
        switch (gem) {
            case BLOOD -> bloodBurst(p, gem);
            case CRIMSON -> crimsonRage(p, gem);
            case SHADOW -> shadowBlink(p, gem);
            case INFERNO -> infernalExecution(p, gem);
            case AVERON -> {
                if (p.isSneaking()) averonRift(p, gem);
                else bloodDominion(p, gem);
            }
        }
    }

    // -------------------------------------------------------------- config

    private String path(GemType g, String ab, String field) {
        return "gems." + g.id() + ".abilities." + ab + "." + field;
    }

    private double d(GemType g, String ab, String field, double def) {
        return plugin.getConfig().getDouble(path(g, ab, field), def);
    }

    private String display(GemType g, String ab) {
        return plugin.getConfig().getString(path(g, ab, "display"), ab);
    }

    // ------------------------------------------------------------ cooldowns

    private boolean ready(Player p, GemType g, String ab, boolean notify) {
        Map<String, Long> m = cooldowns.get(p.getUniqueId());
        if (m == null) return true;
        Long until = m.get(g.id() + "." + ab);
        long now = System.currentTimeMillis();
        if (until != null && until > now) {
            if (notify) {
                double left = Math.ceil((until - now) / 1000.0);
                p.sendActionBar(plugin.rawC("cooldown", "ability", display(g, ab), "time", Msg.fmt(left)));
            }
            return false;
        }
        return true;
    }

    private void startCooldown(Player p, GemType g, String ab) {
        double secs = d(g, ab, "cooldown", 30);
        cooldowns.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>())
                .put(g.id() + "." + ab, System.currentTimeMillis() + (long) (secs * 1000));
    }

    // ------------------------------------------------------------- effects

    private boolean fx() {
        return plugin.getConfig().getBoolean("effects.particles", true);
    }

    private void snd(Location l, String key, float vol, float pitch) {
        if (!plugin.getConfig().getBoolean("effects.sounds", true)) return;
        l.getWorld().playSound(l, key, SoundCategory.PLAYERS, vol, pitch);
    }

    private void dust(Location l, Color c, float size, int count, double spread) {
        if (!fx()) return;
        l.getWorld().spawnParticle(Particle.DUST, l, count, spread, spread, spread, 0,
                new Particle.DustOptions(c, size));
    }

    private void part(Particle pt, Location l, int count, double dx, double dy, double dz, double speed) {
        if (!fx()) return;
        l.getWorld().spawnParticle(pt, l, count, dx, dy, dz, speed);
    }

    private void ring(Location c, double r, Color col, int points) {
        if (!fx()) return;
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            Location l = c.clone().add(Math.cos(a) * r, 0, Math.sin(a) * r);
            c.getWorld().spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, new Particle.DustOptions(col, 1.6f));
        }
    }

    private void line(Location a, Location b, Particle pt) {
        if (!fx()) return;
        Vector dir = b.toVector().subtract(a.toVector());
        double len = dir.length();
        if (len < 0.1) return;
        dir.normalize();
        for (double t = 0; t < len; t += 0.4) {
            Location l = a.clone().add(dir.clone().multiply(t));
            a.getWorld().spawnParticle(pt, l, 1, 0.03, 0.03, 0.03, 0);
        }
    }

    private void aura(Player p, int ticks, Consumer<Location> effect) {
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (!p.isOnline() || p.isDead() || t >= ticks) {
                    cancel();
                    return;
                }
                effect.accept(p.getLocation().add(0, 1, 0));
                t += 4;
            }
        }.runTaskTimer(plugin, 0L, 4L);
    }

    // ------------------------------------------------------------ targeting

    public boolean canHarm(Player attacker, Entity e) {
        if (!(e instanceof LivingEntity le)) return false;
        if (e.equals(attacker) || e instanceof ArmorStand || le.isDead() || !le.isValid()) return false;

        if (e instanceof Player t) {
            if (!attacker.getWorld().getPVP()) return false;
            GameMode gm = t.getGameMode();
            if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return false;
            if (sameTeamProtected(attacker, t)) return false;
        } else {
            if (!plugin.getConfig().getBoolean("protection.affect-mobs", true)) return false;
            if (e instanceof Tameable tm && tm.isTamed()
                    && attacker.getUniqueId().equals(tm.getOwnerUniqueId())) return false;
        }
        return true;
    }

    private boolean sameTeamProtected(Player a, Player b) {
        Team ta = a.getScoreboard().getEntryTeam(a.getName());
        Team tb = b.getScoreboard().getEntryTeam(b.getName());
        if (ta == null || tb == null || !ta.getName().equals(tb.getName())) return false;
        return plugin.getConfig().getBoolean("protection.protect-teammates", true) || !ta.allowFriendlyFire();
    }

    private List<LivingEntity> around(Player p, Location c, double r) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity e : c.getWorld().getNearbyEntities(c, r, r, r)) {
            if (e instanceof LivingEntity le && canHarm(p, le)
                    && le.getLocation().add(0, le.getHeight() / 2, 0).distanceSquared(c) <= r * r) {
                out.add(le);
            }
        }
        return out;
    }

    // ------------------------------------------------------------- teleport

    private boolean isSafe(Location feet) {
        Block b1 = feet.getBlock();
        Block b2 = feet.clone().add(0, 1, 0).getBlock();
        if (!b1.isPassable() || !b2.isPassable()) return false;
        if (b1.getType() == Material.LAVA || b2.getType() == Material.LAVA) return false;
        for (int i = 1; i <= 3; i++) {
            Block below = feet.clone().add(0, -i, 0).getBlock();
            if (below.getType() == Material.LAVA) return false;
            if (!below.isPassable()) break;
        }
        return feet.getY() > feet.getWorld().getMinHeight() + 1;
    }

    private Location findDestination(Player p, double dist) {
        Location origin = p.getLocation();
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        RayTraceResult hit = p.getWorld().rayTraceBlocks(eye, dir, dist, FluidCollisionMode.NEVER, true);
        double max = dist;
        if (hit != null) {
            max = Math.max(0, hit.getHitPosition().distance(eye.toVector()) - 0.8);
        }
        for (double t = max; t >= 0.0; t -= 0.5) {
            Location c = origin.clone().add(dir.clone().multiply(t));
            if (isSafe(c)) return c;
        }
        return null;
    }

    // ---------------------------------------------------------- 1. Blood Gem

    private void bloodBurst(Player p, GemType g) {
        String ab = "blood-burst";
        if (!ready(p, g, ab, true)) return;

        double radius = d(g, ab, "radius", 5);
        double dmg = d(g, ab, "damage", 6);
        double kb = d(g, ab, "knockback", 1.2);
        Location c = p.getLocation().add(0, 1, 0);

        for (LivingEntity t : around(p, c, radius)) {
            Vector push = t.getLocation().toVector().subtract(p.getLocation().toVector());
            push.setY(0);
            if (push.lengthSquared() < 0.01) push = p.getLocation().getDirection().setY(0);
            if (push.lengthSquared() < 0.01) push = new Vector(1, 0, 0);
            t.damage(dmg, p);
            t.setVelocity(push.normalize().multiply(kb).setY(0.4));
        }

        part(Particle.EXPLOSION, c, 2, 0.3, 0.3, 0.3, 0);
        dust(c, Color.fromRGB(190, 0, 0), 1.8f, 120, radius / 2.5);
        part(Particle.DAMAGE_INDICATOR, c, 25, radius / 3, 0.5, radius / 3, 0.1);
        for (double r = 1; r <= radius; r += 1.0) {
            ring(p.getLocation().add(0, 0.2, 0), r, Color.fromRGB(150, 0, 0), (int) (r * 12));
        }
        snd(c, "entity.generic.explode", 0.8f, 0.7f);
        snd(c, "block.respawn_anchor.deplete", 1f, 0.6f);
        startCooldown(p, g, ab);
    }

    // --------------------------------------------------------- 2. Crimson Gem

    private void crimsonRage(Player p, GemType g) {
        String ab = "crimson-rage";
        if (!ready(p, g, ab, true)) return;

        int secs = (int) d(g, ab, "duration-seconds", 10);
        int amp = (int) d(g, ab, "amplifier", 0);
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, secs * 20, amp, false, true, true));

        Location c = p.getLocation().add(0, 1, 0);
        part(Particle.CRIMSON_SPORE, c, 60, 0.6, 0.9, 0.6, 0.05);
        dust(c, Color.fromRGB(220, 20, 60), 1.5f, 50, 0.7);
        aura(p, secs * 20, l -> {
            part(Particle.CRIMSON_SPORE, l, 6, 0.4, 0.7, 0.4, 0.02);
            dust(l, Color.fromRGB(200, 0, 40), 1.2f, 4, 0.5);
        });
        snd(c, "entity.ravager.roar", 0.8f, 0.9f);
        snd(c, "entity.evoker.prepare_summon", 1f, 0.8f);
        startCooldown(p, g, ab);
    }

    // ---------------------------------------------------------- 3. Shadow Gem

    private void shadowBlink(Player p, GemType g) {
        String ab = "shadow-blink";
        if (!ready(p, g, ab, true)) return;

        Location dest = findDestination(p, d(g, ab, "distance", 8));
        if (dest == null) {
            p.sendActionBar(plugin.rawC("no-space"));
            return;
        }
        Location from = p.getLocation();
        part(Particle.PORTAL, from.clone().add(0, 1, 0), 60, 0.4, 0.8, 0.4, 0.3);
        part(Particle.SMOKE, from.clone().add(0, 1, 0), 30, 0.4, 0.8, 0.4, 0.02);
        snd(from, "entity.enderman.teleport", 1f, 1.2f);

        p.teleport(dest);
        p.setFallDistance(0);

        line(from.clone().add(0, 1, 0), dest.clone().add(0, 1, 0), Particle.SMOKE);
        part(Particle.REVERSE_PORTAL, dest.clone().add(0, 1, 0), 60, 0.4, 0.8, 0.4, 0.2);
        dust(dest.clone().add(0, 1, 0), Color.fromRGB(60, 0, 90), 1.5f, 30, 0.5);
        snd(dest, "entity.enderman.teleport", 1f, 0.8f);
        startCooldown(p, g, ab);
    }

    // --------------------------------------------------------- 4. Inferno Gem

    private void infernalExecution(Player p, GemType g) {
        String ab = "infernal-execution";
        if (!ready(p, g, ab, true)) return;

        double range = d(g, ab, "range", 8);
        double dmg = d(g, ab, "damage", 8);
        double thresholdPct = d(g, ab, "execute-threshold-percent", 30);
        double bonus = d(g, ab, "execute-bonus-damage", 8);
        int fireTicks = (int) d(g, ab, "fire-seconds", 5) * 20;
        int slowTicks = (int) d(g, ab, "slowness-seconds", 5) * 20;
        int slowAmp = (int) d(g, ab, "slowness-amplifier", 1);

        Location eye = p.getEyeLocation();
        RayTraceResult rr = p.getWorld().rayTraceEntities(eye, eye.getDirection(), range, 0.6,
                en -> canHarm(p, en));
        if (rr == null || rr.getHitEntity() == null) {
            p.sendActionBar(plugin.rawC("no-target"));
            return;
        }
        LivingEntity t = (LivingEntity) rr.getHitEntity();

        AttributeInstance ai = t.getAttribute(Attribute.MAX_HEALTH);
        double maxHp = ai == null ? 20 : ai.getValue();
        boolean execute = t.getHealth() <= maxHp * thresholdPct / 100.0;

        Location tl = t.getLocation().add(0, t.getHeight() / 2, 0);
        line(p.getLocation().add(0, 1.2, 0), tl, Particle.FLAME);

        t.setFireTicks(fireTicks);
        t.damage(dmg + (execute ? bonus : 0), p);
        if (!t.isDead()) {
            t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slowTicks, slowAmp));
        }

        part(Particle.FLAME, tl, 50, 0.4, 0.6, 0.4, 0.08);
        part(Particle.LAVA, tl, 15, 0.4, 0.6, 0.4, 0);
        part(Particle.SOUL_FIRE_FLAME, tl, execute ? 40 : 10, 0.4, 0.6, 0.4, 0.05);
        snd(tl, "entity.blaze.shoot", 1f, 0.7f);
        snd(tl, execute ? "entity.wither.break_block" : "item.firecharge.use", 1f, 0.9f);
        startCooldown(p, g, ab);
    }

    // ---------------------------------------------------------- 5. Averon Gem

    private void bloodDominion(Player p, GemType g) {
        String ab = "blood-dominion";
        if (!ready(p, g, ab, true)) return;

        double secs = d(g, ab, "duration-seconds", 8);
        blood.activateDominion(p, secs);

        Location c = p.getLocation().add(0, 1, 0);
        part(Particle.TOTEM_OF_UNDYING, c, 60, 0.5, 0.9, 0.5, 0.3);
        dust(c, Color.fromRGB(255, 170, 0), 1.6f, 60, 0.7);
        aura(p, (int) (secs * 20), l -> {
            dust(l, Color.fromRGB(255, 60, 0), 1.3f, 6, 0.6);
            part(Particle.END_ROD, l, 2, 0.4, 0.8, 0.4, 0.01);
        });
        snd(c, "block.beacon.activate", 1f, 1.4f);
        snd(c, "entity.wither.spawn", 0.5f, 1.6f);
        p.sendActionBar(plugin.rawC("dominion-on", "time", Msg.fmt(secs)));
        startCooldown(p, g, ab);
    }

    private void averonRift(Player p, GemType g) {
        String ab = "averon-rift";
        if (!ready(p, g, ab, true)) return;

        Location dest = findDestination(p, d(g, ab, "distance", 10));
        if (dest == null) {
            p.sendActionBar(plugin.rawC("no-space"));
            return;
        }
        double radius = d(g, ab, "radius", 4);
        double dmg = d(g, ab, "damage", 10);
        Location from = p.getLocation();

        part(Particle.REVERSE_PORTAL, from.clone().add(0, 1, 0), 80, 0.5, 0.9, 0.5, 0.3);
        snd(from, "entity.enderman.teleport", 1f, 0.6f);

        p.teleport(dest);
        p.setFallDistance(0);
        line(from.clone().add(0, 1, 0), dest.clone().add(0, 1, 0), Particle.END_ROD);

        Location c = dest.clone().add(0, 1, 0);
        for (LivingEntity t : around(p, c, radius)) {
            Vector push = t.getLocation().toVector().subtract(dest.toVector()).setY(0);
            if (push.lengthSquared() < 0.01) push = new Vector(1, 0, 0);
            t.damage(dmg, p);
            t.setVelocity(push.normalize().multiply(1.0).setY(0.45));
        }
        part(Particle.EXPLOSION, c, 3, 0.5, 0.5, 0.5, 0);
        part(Particle.END_ROD, c, 80, radius / 2, 0.8, radius / 2, 0.15);
        dust(c, Color.fromRGB(255, 200, 40), 1.8f, 80, radius / 2);
        for (double r = 1; r <= radius; r += 1.0) {
            ring(dest.clone().add(0, 0.2, 0), r, Color.fromRGB(255, 120, 0), (int) (r * 12));
        }
        snd(dest, "entity.generic.explode", 0.8f, 1.2f);
        snd(dest, "entity.ender_dragon.growl", 0.6f, 1.4f);
        startCooldown(p, g, ab);
    }

    /** Passive: called after the player takes damage (see GemListener). */
    public void supremeBlood(Player p, double finalDamage) {
        if (items.strongestGem(p) != GemType.AVERON) return;
        GemType g = GemType.AVERON;
        String ab = "supreme-blood";
        if (!ready(p, g, ab, false)) return;
        if (p.getHealth() <= 0) return;

        AttributeInstance ai = p.getAttribute(Attribute.MAX_HEALTH);
        double max = ai == null ? 20 : ai.getValue();
        double after = p.getHealth() - finalDamage;
        double threshold = max * d(g, ab, "health-threshold-percent", 30) / 100.0;
        if (after <= 0 || after > threshold) return;

        int secs = (int) d(g, ab, "duration-seconds", 3);
        int amp = (int) d(g, ab, "amplifier", 0);
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, secs * 20, amp, false, true, true));

        Location c = p.getLocation().add(0, 1, 0);
        part(Particle.TOTEM_OF_UNDYING, c, 40, 0.4, 0.8, 0.4, 0.25);
        dust(c, Color.fromRGB(255, 215, 0), 1.5f, 40, 0.6);
        snd(c, "item.totem.use", 0.6f, 1.5f);
        p.sendActionBar(plugin.rawC("supreme-blood"));
        startCooldown(p, g, ab);
    }
}
